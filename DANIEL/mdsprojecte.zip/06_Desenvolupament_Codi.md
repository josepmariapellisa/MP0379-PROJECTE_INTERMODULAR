# Desenvolupament del codi de l'eina

<!-- Explicació tècnica del desenvolupament del codi -->
