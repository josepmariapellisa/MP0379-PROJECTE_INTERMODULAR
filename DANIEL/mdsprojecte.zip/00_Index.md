# Índex del Projecte

1. [Introducció](./01_Introduccio.md)
2. [Raó del projecte Auditoria i en què consisteix](./02_Rao_Projecte.md)
3. [Metodologia Scrum](./03_Metodologia_Scrum.md)
4. [Administració](./04_Administracio.md)
    - Anàlisi de riscos
    - Contracte auditoria
    - Empreses del sector
5. [Landing Page (Marketing)](./05_Landing_Page.md)
6. [Desenvolupament del codi de l'eina](./06_Desenvolupament_Codi.md)
7. [Pla de millora](./07_Pla_Millora.md)
8. [Conclusions](./08_Conclusions.md)
9. [Annexos](./09_Annexos.md)
