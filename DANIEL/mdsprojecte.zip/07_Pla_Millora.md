# Pla de millora

<!-- Futures millores i evolució del projecte -->
