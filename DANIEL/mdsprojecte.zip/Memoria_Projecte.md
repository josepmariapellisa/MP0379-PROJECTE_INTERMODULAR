# Estructura del Projecte

## 1. Introducció
<!-- Escriu aquí la introducció del projecte -->

## 2. Raó del projecte Auditoria i en què consisteix
<!-- Explica la raó de ser del projecte i la seva definició -->

## 3. Metodologia Scrum
<!-- Detalls sobre la metodologia Scrum utilitzada -->

## 4. Administració
<!-- Gestió del projecte -->

### 4.1 Anàlisi de riscos
<!-- Anàlisi dels riscos del projecte -->

### 4.2 Contracte auditoria
<!-- Detalls del contracte d'auditoria -->

### 4.3 Empreses del sector
<!-- Informació sobre altres empreses del sector -->

## 5. Landing Page (Marketing)
<!-- Estratègia de màrqueting i landing page -->

## 6. Desenvolupament del codi de l'eina
<!-- Explicació tècnica del desenvolupament del codi -->

## 7. Pla de millora
<!-- Futures millores i evolució del projecte -->

## 8. Conclusions
<!-- Conclusions finals -->

## 9. Annexos
<!-- Documentació addicional i annexos -->
