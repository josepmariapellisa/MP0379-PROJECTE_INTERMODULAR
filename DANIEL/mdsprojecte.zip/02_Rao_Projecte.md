# Raó del projecte Auditoria i en què consisteix

<!-- Explica la raó de ser del projecte i la seva definició -->
