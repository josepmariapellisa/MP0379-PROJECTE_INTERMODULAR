# Metodologia Scrum

<!-- Detalls sobre la metodologia Scrum utilitzada -->
