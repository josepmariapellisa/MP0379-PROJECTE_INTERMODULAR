# Administració

## Anàlisi de riscos
<!-- Anàlisi dels riscos del projecte -->

## Contracte auditoria
<!-- Detalls del contracte d'auditoria -->

## Empreses del sector
<!-- Informació sobre altres empreses del sector -->
