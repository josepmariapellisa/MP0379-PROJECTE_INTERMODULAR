# Landing Page (Marketing)

<!-- Estratègia de màrqueting i landing page -->
